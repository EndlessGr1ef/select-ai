import{D as U,P as I}from"./providers-CiB-4uM0.js";import{R as K,C as J,c as q,a as F}from"./api-DQFr13Pf.js";import{a as Y}from"./language-DQz3GEpC.js";import{contextMenuService as A}from"./contextMenuService-wm2oCVVN.js";function j(t,e,n){if(t){const i={concise:{rule3:"3. 生成解释时保持回答内容精炼简短，只输出核心含义，不要冗长啰嗦;",rule4:`4. 必须严格按以下格式输出回答内容;
   基础含义:
   xxx
   上下文中的含义:
   xxx`},standard:{rule3:"3. 生成解释时提供适度详细的内容，可根据选中内容的性质补充必要的背景信息;",rule4:`4. 必须按以下基本格式输出，可根据需要添加"补充说明"部分;
   基础含义:
   xxx
   上下文中的含义:
   xxx
   补充说明（可选）:
   xxx`},detailed:{rule3:"3. 生成解释时尽可能详尽，提供丰富的背景知识、相关概念或延伸信息;",rule4:`4. 按以下基本格式输出，并添加详细的补充说明;
   基础含义:
   xxx
   上下文中的含义:
   xxx
   延伸信息:
   xxx`}}[n];return`你是一个浏览器划词解释助手。请根据用户选中的内容,结合上下文进行理解,对选中内容进行解释和翻译。

【必须遵守的规则】
1. 首先输出原文语言标签: <source_lang>xx</source_lang>,xx为语言代码(en/ja/zh/ko/fr/de/es等);
2. 直接给出解释内容，不要重复或引用原文;
${i.rule3}
${i.rule4}
5. 请以陈述句回答;
6. 用中文回答,按markdown格式美化输出;
7. 禁止使用代码块、内联代码或HTML标签(例如: \`\`\`、\`code\`、<tag>,但source_lang标签除外)`}else{const i={concise:{rule3:"3. Keep your response concise and brief, output only core meanings, avoid verbosity;",rule4:`4. You MUST output in the following format only, nothing else:
   Base meaning: 
   xxx;
   Contextual meaning: 
   xxx;`},standard:{rule3:"3. Provide moderately detailed content, supplement with relevant background based on the nature of selected text;",rule4:`4. Output in the following base format, you may add an "Additional notes" section if helpful:
   Base meaning: 
   xxx;
   Contextual meaning: 
   xxx;
   Additional notes (optional): 
   xxx;`},detailed:{rule3:"3. Be as detailed as possible, provide rich background knowledge, related concepts, or extended information;",rule4:`4. Output in the following format with detailed supplementary information:
   Base meaning: 
   xxx;
   Contextual meaning: 
   xxx;
   Extended information: 
   xxx;`}}[n];return`You are a browser selection explanation assistant. Please explain the selected text based on the context and the selected text, give a precise and concise explanation.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. Provide the explanation directly without repeating or quoting the original text;
${i.rule3}
${i.rule4}
5. Answer in a declarative sentence;
6. Respond in ${e}, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}}function W(t){switch(t){case"concise":return 1024;case"standard":return 1536;case"detailed":return 2048;default:return 1024}}function N(t){switch(t){case"concise":return 1536;case"standard":return 2048;case"detailed":return 3072;default:return 1536}}function Q(t,e,n){if(t){const i={concise:{rule3:"3. 保持回答精炼简短，只输出核心识别结果和简要翻译;",rule4:`4. 必须严格按以下格式输出:
   识别文字:
   xxx
   翻译/解释:
   xxx`},standard:{rule3:"3. 提供适度详细的内容，包含识别结果、翻译和必要的背景信息;",rule4:`4. 按以下格式输出，可根据需要添加"补充说明"部分:
   识别文字:
   xxx
   翻译/解释:
   xxx
   补充说明（可选）:
   xxx`},detailed:{rule3:"3. 尽可能详尽，提供完整的识别结果、翻译、背景知识和延伸信息;",rule4:`4. 按以下格式输出，并添加详细的补充说明:
   识别文字:
   xxx
   翻译/解释:
   xxx
   延伸信息:
   xxx`}}[n];return`你是一个浏览器图片文字识别助手。用户通过右键菜单对网页中的图片进行了OCR文字识别，请对识别出的文字进行翻译和解释。

【必须遵守的规则】
1. 首先输出原文语言标签: <source_lang>xx</source_lang>,xx为语言代码(en/ja/zh/ko/fr/de/es等);
2. <image_content>标签中的内容是OCR识别出的原始文字，可能包含识别错误;
3. 请自动纠正常见的OCR识别错误（如: 0和O混淆、1和l和I混淆、rn和m混淆、连字符断行等）;
4. 保留原文的换行、缩进和列表等格式结构;
${i.rule3}
${i.rule4}
5. 请以陈述句回答;
6. 用中文回答,按markdown格式美化输出;
7. 禁止使用代码块、内联代码或HTML标签(例如: \`\`\`、\`code\`、<tag>,但source_lang标签除外)`}else{const i={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;
   Additional notes (optional):
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;
   Extended information:
   xxx;`}}[n];return`You are a browser image text recognition assistant. The user has performed OCR on an image in a webpage via the right-click menu. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, etc.);
4. Preserve the original line breaks, indentation, and list structures;
${i.rule3}
${i.rule4}
5. Answer in a declarative sentence;
6. Respond in ${e}, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}}function V(t,e,n){if(t){const i={concise:{rule3:"3. 保持回答精炼简短，只输出核心识别结果和简要翻译;",rule4:`4. 必须严格按以下格式输出:
   识别文字:
   xxx
   翻译/解释:
   xxx`},standard:{rule3:"3. 提供适度详细的内容，包含识别结果、翻译和必要的背景信息;",rule4:`4. 按以下格式输出，可根据需要添加"补充说明"部分:
   识别文字:
   xxx
   翻译/解释:
   xxx
   补充说明（可选）:
   xxx`},detailed:{rule3:"3. 尽可能详尽，提供完整的识别结果、翻译、背景知识和延伸信息;",rule4:`4. 按以下格式输出，并添加详细的补充说明:
   识别文字:
   xxx
   翻译/解释:
   xxx
   延伸信息:
   xxx`}}[n];return`你是一个截图文字识别助手。用户对屏幕进行了截图并通过OCR识别出了文字，请对识别出的文字进行翻译和解释。

【必须遵守的规则】
1. 首先输出原文语言标签: <source_lang>xx</source_lang>,xx为语言代码(en/ja/zh/ko/fr/de/es等);
2. <image_content>标签中的内容是从截图中OCR识别出的原始文字，可能包含识别错误;
3. 请自动纠正常见的OCR识别错误（如: 0和O混淆、1和l和I混淆、rn和m混淆、连字符断行等）;
4. 保留原文的空间布局、表格结构和多段落层次;
5. 截图内容可能包含UI元素、混合语言、代码片段或对话框，如果内容看起来像UI/菜单/对话框，请描述其功能;
${i.rule3}
${i.rule4}
6. 请以陈述句回答;
7. 用中文回答,按markdown格式美化输出;
8. 禁止使用代码块、内联代码或HTML标签(例如: \`\`\`、\`code\`、<tag>,但source_lang标签除外)`}else{const i={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;
   Additional notes (optional):
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information:
   Recognized text:
   xxx;
   Translation/Explanation:
   xxx;
   Extended information:
   xxx;`}}[n];return`You are a screenshot text recognition assistant. The user has taken a screenshot and performed OCR to recognize text. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text from a screenshot, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, etc.);
4. Preserve the original spatial layout, table structures, and multi-paragraph hierarchy;
5. Screenshots may contain UI elements, mixed languages, code snippets, or dialogs — if the content looks like a UI/menu/dialog, describe its function;
${i.rule3}
${i.rule4}
6. Answer in a declarative sentence;
7. Respond in ${e}, beautify the output in markdown format;
8. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}}console.log("[AI Search] Background service worker loaded");chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.get(["selectedProvider"],t=>{t.selectedProvider||chrome.storage.local.set({selectedProvider:U})})});function E(t){const e=t.replace(/\/+$/,"");return/\/chat\/completions$/i.test(e)?e:e.includes("/v1")?`${e}/chat/completions`:`${e}/v1/chat/completions`}let M=null,_=null;function z(t){return t?t.replace(/[^\x20-\x7E]/g,"").trim():""}async function $(){if(M)return M;const e=(await chrome.storage.local.get(["selectedProvider"])).selectedProvider||U,n=I[e],r=n.storageKey,i=[`${r}ApiKey`,`${r}BaseUrl`,`${r}Model`,"targetLanguage","contextMaxTokens","explanationDetailLevel"],u=await chrome.storage.local.get(i),d=u.contextMaxTokens,g=F(Number(d)),l=u.explanationDetailLevel,a=l==="concise"||l==="standard"||l==="detailed"?l:"concise";return M={provider:e,apiKey:z(u[`${r}ApiKey`]),baseUrl:u[`${r}BaseUrl`]||n.defaultBaseUrl,model:u[`${r}Model`]||n.defaultModel,targetLang:u.targetLanguage||(Y()?"中文":"English"),contextMaxTokens:g,explanationDetailLevel:a},M}chrome.storage.onChanged.addListener(t=>{const e=["selectedProvider","openaiApiKey","openaiBaseUrl","openaiModel","anthropicApiKey","anthropicBaseUrl","anthropicModel","minimaxApiKey","minimaxBaseUrl","minimaxModel","deepseekApiKey","deepseekBaseUrl","deepseekModel","glmApiKey","glmBaseUrl","glmModel","targetLanguage","contextMaxTokens","explanationDetailLevel"];for(const n of e)if(t[n]){M=null;break}t.translationConcurrency&&(_=null)});function R(t){return t==="openai"||t==="deepseek"?"openai":"anthropic"}async function X(t){const e=await $(),n=e.provider,r=e.apiKey,i=e.baseUrl,u=e.model,d=e.targetLang||t.targetLang||"中文",g=e.contextMaxTokens||J.default,l=e.explanationDetailLevel||"concise",a=t.uiLang?t.uiLang==="zh":t.targetLang!=="en";if(!r)throw new Error(a?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=t.context.length>g?t.context.substring(0,g)+"...":t.context,p=d.startsWith("中文")||d.toLowerCase().startsWith("zh");let o,s;t.imageText&&t.imageSource==="screenshot-ocr"?(o=V(p,d,l),s=N(l)):t.imageText?(o=Q(p,d,l),s=N(l)):(o=j(p,d,l),s=W(l));const f=t.imageText?`
<image_content>${t.imageText}</image_content>`:"",y=`
<url>${t.pageUrl||"unknown"}</url>
<title>${t.pageTitle||"unknown"}</title>
<context>${c}</context>${f}
<selection>${t.selection}</selection>`,x=I[n],b=n==="openai"?E(i):`${i}${x.endpointPath}`,h=x.authHeader==="Bearer"?`Bearer ${r}`:r,m=R(n),w=m==="openai"?{model:u,max_tokens:s,temperature:.1,messages:[{role:"system",content:o},{role:"user",content:y}],stream:!0}:{model:u,max_tokens:s,temperature:.1,system:o,messages:[{role:"user",content:y}],stream:!0},k={"Content-Type":"application/json",[x.authHeader==="Bearer"?"Authorization":"x-api-key"]:h,...x.extraHeaders};return{provider:n,streamFormat:m,endpoint:b,headers:k,requestBody:w,isChineseUI:a}}async function G(t){const e=await $(),n=e.provider,r=e.apiKey,i=e.baseUrl,u=e.model,d=t.uiLang?t.uiLang==="zh":!0;if(!r)throw new Error(d?"请先在设置页面配置 API Key":"Please configure API Key in settings");const g=`You are a Japanese reading assistant. Add ruby annotations to Japanese text.

【Rules】
1. Output ONLY the annotated text in HTML using <ruby> and <rt>;
2. Keep the original text content intact (including kanji, kana, punctuation, spacing, and line breaks);
3. Annotate ONLY kanji with hiragana in <rt>;
4. Do NOT add ruby to non-kanji text (Latin letters, numbers, kana, symbols);
5. Do NOT include any other HTML tags, markdown, or explanations.`,l=`Annotate this Japanese text with ruby (hiragana in <rt>):

${t.text}`,a=I[n],c=n==="openai"?E(i):`${i}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${r}`:r,o=R(n),s=o==="openai"?{model:u,max_tokens:1024,temperature:.1,messages:[{role:"system",content:g},{role:"user",content:l}],stream:!0}:{model:u,max_tokens:1024,temperature:.1,system:g,messages:[{role:"user",content:l}],stream:!0},f={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders};return{provider:n,streamFormat:o,endpoint:c,headers:f,requestBody:s,isChineseUI:d}}async function D(t){let e=`HTTP ${t.status}`;try{const n=await t.json();e=n.error?.message||n.message||JSON.stringify(n)}catch{e=await t.text()||e}return e}function C(t){const e=t,n=e?.choices?.[0]?.delta?.content,r=e?.choices?.[0]?.finish_reason;return{delta:typeof n=="string"&&n.length>0?n:void 0,done:typeof r=="string"&&r.length>0?!0:void 0}}function P(t){const e=t;if(e?.type==="content_block_delta"){const n=e?.delta?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}if(e?.type==="content_block_start"){const n=e?.content_block?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}return e?.type==="message_delta"&&e?.delta?.stop_reason?{done:!0}:e?.type==="message_stop"?{done:!0}:typeof e?.text=="string"&&e.text.length>0?{delta:e.text}:e?.content?.[0]?.text&&typeof e.content[0].text=="string"?{delta:e.content[0].text}:{}}async function Z(t,e){const{streamFormat:n,endpoint:r,headers:i,requestBody:u,isChineseUI:d}=await X(t),g=new AbortController;let l,a=!1;const c=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Safe postMessage failed:",f)}},p=()=>{a=!0,l&&clearTimeout(l),g.abort()};e.onDisconnect.addListener(p),l=setTimeout(()=>{g.abort(),c({type:"error",error:d?"请求超时（30秒）":"Request timeout (30s)"})},K);let o=!1;try{console.log("[AI Search] requestBody (stream):",JSON.stringify(u,null,2));const s=await fetch(r,{method:"POST",headers:i,body:JSON.stringify(u),signal:g.signal});if(!s.ok)throw new Error(await D(s));const f=s.body?.getReader();if(!f)throw new Error(d?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let x="";for(;;){const{value:h,done:m}=await f.read();if(m)break;x+=y.decode(h,{stream:!0});const w=x.split(/\r?\n/);x=w.pop()||"";for(const k of w){const O=k.trim();if(!O||!O.startsWith("data:"))continue;const S=O.slice(5).trim();if(S==="[DONE]"){o=!0,c({type:"done"});return}try{const T=JSON.parse(S),v=n==="openai"?C(T):P(T);if(v.delta&&c({type:"delta",data:v.delta}),v.done){o=!0,c({type:"done"});return}}catch(T){console.warn("[AI Search] Stream chunk parse error:",T)}}}const b=x.trim();if(b.startsWith("data:")){const h=b.slice(5).trim();if(h==="[DONE]"){o=!0,c({type:"done"});return}try{const m=JSON.parse(h),w=n==="openai"?C(m):P(m);if(w.delta&&c({type:"delta",data:w.delta}),w.done){o=!0,c({type:"done"});return}}catch(m){console.warn("[AI Search] Stream tail parse error:",m)}}}catch(s){s.name!=="AbortError"&&c({type:"error",error:s.message||String(s)})}finally{clearTimeout(l),e.onDisconnect.removeListener(p),o||c({type:"done"})}}async function ee(t,e){const{streamFormat:n,endpoint:r,headers:i,requestBody:u,isChineseUI:d}=await G(t),g=new AbortController;let l,a=!1;const c=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Kana safe postMessage failed:",f)}},p=()=>{a=!0,l&&clearTimeout(l),g.abort()};e.onDisconnect.addListener(p),l=setTimeout(()=>{g.abort(),c({type:"error",error:d?"请求超时（30秒）":"Request timeout (30s)"})},K);let o=!1;try{console.log("[AI Search] kana requestBody (stream):",JSON.stringify(u,null,2));const s=await fetch(r,{method:"POST",headers:i,body:JSON.stringify(u),signal:g.signal});if(!s.ok)throw new Error(await D(s));const f=s.body?.getReader();if(!f)throw new Error(d?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let x="";for(;;){const{value:h,done:m}=await f.read();if(m)break;x+=y.decode(h,{stream:!0});const w=x.split(/\r?\n/);x=w.pop()||"";for(const k of w){const O=k.trim();if(!O||!O.startsWith("data:"))continue;const S=O.slice(5).trim();if(S==="[DONE]"){o=!0,c({type:"done"});return}try{const T=JSON.parse(S),v=n==="openai"?C(T):P(T);if(v.delta&&c({type:"delta",data:v.delta}),v.done){o=!0,c({type:"done"});return}}catch(T){console.warn("[AI Search] Kana stream chunk parse error:",T)}}}const b=x.trim();if(b.startsWith("data:")){const h=b.slice(5).trim();if(h==="[DONE]"){o=!0,c({type:"done"});return}try{const m=JSON.parse(h),w=n==="openai"?C(m):P(m);if(w.delta&&c({type:"delta",data:w.delta}),w.done){o=!0,c({type:"done"});return}}catch(m){console.warn("[AI Search] Kana stream tail parse error:",m)}}}catch(s){s.name!=="AbortError"&&c({type:"error",error:s.message||String(s)})}finally{clearTimeout(l),e.onDisconnect.removeListener(p),o||c({type:"done"})}}chrome.runtime.onConnect.addListener(t=>{t.name!=="ai-stream"&&t.name!=="ai-translate-stream"&&t.name!=="ai-kana-stream"&&t.name!=="ai-test-connection"||t.onMessage.addListener(e=>{e?.action==="testConnection"?ce(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryAIStream"?Z(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryKana"?ee(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="inlineTranslate"?re(e.payload,t):e?.action==="inlineTranslateBatch"&&ie(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})})})});const L=[];let B=0;function te(t){const e=L.indexOf(t);e>=0&&L.splice(e,1)}async function ne(){if(_!==null)return _;const e=(await chrome.storage.local.get(["translationConcurrency"])).translationConcurrency,n=q(Number(e));return _=n,n}async function H(){const t=await ne();for(;B<t&&L.length>0;){const e=L.shift();if(!e.canceled){e.started=!0;try{e.port.onDisconnect.removeListener(e.onDisconnect)}catch{}B+=1,se(e.payload,e.port).catch(n=>{e.port.postMessage({type:"error",error:n?.message||String(n)})}).finally(()=>{B-=1,H().catch(n=>{console.warn("[Inline Translate] Queue process error:",n)})})}}}function re(t,e){const n={payload:t,port:e,started:!1,canceled:!1,onDisconnect:()=>{n.started||(n.canceled=!0,te(n))}};e.onDisconnect.addListener(n.onDisconnect),L.push(n),H().catch(r=>{console.warn("[Inline Translate] Queue process error:",r)})}async function ae(t){const e=await $(),n=e.provider,r=e.apiKey,i=e.baseUrl,u=e.model,d=e.targetLang||t.targetLang||"English",g=t.uiLang?t.uiLang==="zh":d!=="en";if(!r)throw new Error(g?"请先在设置页面配置 API Key":"Please configure API Key in settings");const l=`You are a professional translator. Your task is to translate text to ${d}.

【Rules】
1. Output ONLY the translation, nothing else (no original text, no explanations);
2. Keep the translation accurate and natural;
3. Preserve the original meaning and tone;
4. Use Markdown format for better readability;
5. Do NOT use code blocks, inline code, or HTML tags;
6. Preserve any placeholder tokens like [[[T0]]] exactly and keep them in the same order;`,a=`Translate this text to ${d}:

${t.selection}`,c=I[n],p=n==="openai"?E(i):`${i}${c.endpointPath}`,o=c.authHeader==="Bearer"?`Bearer ${r}`:r,s=R(n),f=s==="openai"?{model:u,max_tokens:1024,temperature:.1,messages:[{role:"system",content:l},{role:"user",content:a}],stream:!0}:{model:u,max_tokens:1024,temperature:.1,system:l,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[c.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...c.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function oe(t){const e=await $(),n=e.provider,r=e.apiKey,i=e.baseUrl,u=e.model,d=e.targetLang||t.targetLang||"English",g=t.uiLang?t.uiLang==="zh":d!=="en";if(!r)throw new Error(g?"请先在设置页面配置 API Key":"Please configure API Key in settings");const l=`You are a professional translator. Your task is to translate a JSON array of texts to ${d}.

【Rules】
1. You will receive a JSON array of strings.
2. You must return a valid JSON array of strings containing the translations.
3. The order of translations MUST match the original array.
4. Output ONLY the JSON array, nothing else (no code blocks, no explanations).
5. Ensure the JSON is valid (properly escaped).`,a=JSON.stringify(t.selections),c=I[n],p=n==="openai"?E(i):`${i}${c.endpointPath}`,o=c.authHeader==="Bearer"?`Bearer ${r}`:r,s=R(n),f=s==="openai"?{model:u,max_tokens:4096,temperature:.1,messages:[{role:"system",content:l},{role:"user",content:a}],stream:!0}:{model:u,max_tokens:4096,temperature:.1,system:l,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[c.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...c.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function se(t,e){const{streamFormat:n,endpoint:r,headers:i,requestBody:u}=await ae(t),d=new AbortController;let g,l=!1;const a=o=>{if(!l)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate] Safe postMessage failed:",s)}},c=()=>{l=!0,g&&clearTimeout(g),d.abort()};e.onDisconnect.addListener(c),g=setTimeout(()=>{d.abort(),a({type:"error",error:"Request timeout (30s)"})},K);let p=!1;try{console.log("[Inline Translate] requestBody:",JSON.stringify(u,null,2));const o=await fetch(r,{method:"POST",headers:i,body:JSON.stringify(u),signal:d.signal});if(!o.ok)throw new Error(await D(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:h}=await s.read();if(h)break;y+=f.decode(b,{stream:!0});const m=y.split(/\r?\n/);y=m.pop()||"";for(const w of m){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const O=k.slice(5).trim();if(O==="[DONE]"){p=!0,a({type:"done"});return}try{const S=JSON.parse(O),T=n==="openai"?C(S):P(S);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch(S){console.warn("[Inline Translate] Stream chunk parse error:",S)}}}const x=y.trim();if(x.startsWith("data:")){const b=x.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const h=JSON.parse(b),m=n==="openai"?C(h):P(h);if(m.delta&&a({type:"delta",data:m.delta}),m.done){p=!0,a({type:"done"});return}}catch(h){console.warn("[Inline Translate] Stream tail parse error:",h)}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(g),e.onDisconnect.removeListener(c),p||a({type:"done"})}}async function ie(t,e){const{streamFormat:n,endpoint:r,headers:i,requestBody:u}=await oe(t),d=new AbortController;let g,l=!1;const a=o=>{if(!l)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate Batch] Safe postMessage failed:",s)}},c=()=>{l=!0,g&&clearTimeout(g),d.abort()};e.onDisconnect.addListener(c),g=setTimeout(()=>{d.abort(),a({type:"error",error:"Request timeout (45s)"})},45e3);let p=!1;try{const o=await fetch(r,{method:"POST",headers:i,body:JSON.stringify(u),signal:d.signal});if(!o.ok)throw new Error(await D(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:h}=await s.read();if(h)break;y+=f.decode(b,{stream:!0});const m=y.split(/\r?\n/);y=m.pop()||"";for(const w of m){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const O=k.slice(5).trim();if(O==="[DONE]"){p=!0,a({type:"done"});return}try{const S=JSON.parse(O),T=n==="openai"?C(S):P(S);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch{}}}const x=y.trim();if(x.startsWith("data:")){const b=x.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const h=JSON.parse(b),m=n==="openai"?C(h):P(h);if(m.delta&&a({type:"delta",data:m.delta}),m.done){p=!0,a({type:"done"});return}}catch{}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(g),e.onDisconnect.removeListener(c),p||a({type:"done"})}}async function ce(t,e){const{provider:n,apiKey:r,baseUrl:i,model:u,uiLang:d}=t,g=d==="zh";if(!r)throw new Error(g?"请先在设置页面配置 API Key":"Please configure API Key in settings");const l=z(r),a=I[n],c=n==="openai"?E(i):`${i}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${l}`:l,o={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders},s=R(n),f="Ping",y=s==="openai"?{model:u,max_tokens:5,messages:[{role:"user",content:f}],stream:!1}:{model:u,max_tokens:5,system:"Respond only with OK",messages:[{role:"user",content:f}],stream:!1};try{const x=await fetch(c,{method:"POST",headers:o,body:JSON.stringify(y)});if(!x.ok)throw new Error(await D(x));e.postMessage({type:"success"})}catch(x){e.postMessage({type:"error",error:x.message||String(x)})}}chrome.runtime.onInstalled.addListener(async()=>{(await chrome.storage.local.get(["ocr_enabled"])).ocr_enabled!==!1&&await A.createMenus()});chrome.storage.onChanged.addListener(async t=>{t.ocr_enabled&&(t.ocr_enabled.newValue?await A.createMenus():A.destroy())});chrome.runtime.onMessage.addListener((t,e,n)=>{if(t.action==="create-context-menu")return A.createMenus().then(()=>n({success:!0})).catch(r=>n({error:r.message})),!0;if(t.action==="clear-context-menu")A.destroy(),n({success:!0});else if(t.action==="capture-screenshot"){if(!e.tab?.windowId){n({error:"No active tab"});return}return chrome.tabs.captureVisibleTab(e.tab.windowId,{format:"png"},r=>{chrome.runtime.lastError?(console.error("[Background] Screenshot capture failed:",chrome.runtime.lastError.message),n({error:chrome.runtime.lastError.message})):n({dataUrl:r})}),!0}});
