import{D as R,P as A}from"./providers-CEYn_6Hv.js";import{R as _,C as J,c as q,a as F}from"./api-DQFr13Pf.js";import{a as Y}from"./language-BTadIiMp.js";import{contextMenuService as I}from"./contextMenuService-wm2oCVVN.js";function j(t,e,n){if(t){const g={concise:{rule3:"3. 生成解释时保持回答内容精炼简短，只输出核心含义，不要冗长啰嗦;",rule4:`4. 必须严格按以下格式输出回答内容 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx`},standard:{rule3:"3. 生成解释时提供适度详细的内容，可根据选中内容的性质补充必要的背景信息;",rule4:`4. 必须按以下基本格式输出，可根据需要添加"补充说明"部分 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx
   **补充说明（可选）**:
   xxx`},detailed:{rule3:"3. 生成解释时尽可能详尽，提供丰富的背景知识、相关概念或延伸信息;",rule4:`4. 按以下基本格式输出，并添加详细的补充说明 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx
   **延伸信息**:
   xxx`}}[n];return`你是一个浏览器划词解释助手。请根据用户选中的内容,结合上下文进行理解,对选中内容进行解释和翻译。

【必须遵守的规则】
1. 首先输出原文语言标签: <source_lang>xx</source_lang>,xx为语言代码(en/ja/zh/ko/fr/de/es等);
2. 直接给出解释内容，不要重复或引用原文;
${g.rule3}
${g.rule4}
5. 请以陈述句回答;
6. 用中文回答,按markdown格式美化输出;
7. 禁止使用代码块、内联代码或HTML标签(例如: \`\`\`、\`code\`、<tag>,但source_lang标签除外)`}else{const g={concise:{rule3:"3. Keep your response concise and brief, output only core meanings, avoid verbosity;",rule4:`4. You MUST output in the following format only, nothing else (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;`},standard:{rule3:"3. Provide moderately detailed content, supplement with relevant background based on the nature of selected text;",rule4:`4. Output in the following base format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;
   **Additional notes (optional)**: 
   xxx;`},detailed:{rule3:"3. Be as detailed as possible, provide rich background knowledge, related concepts, or extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;
   **Extended information**: 
   xxx;`}}[n];return`You are a browser selection explanation assistant. Please explain the selected text based on the context and the selected text, give a precise and concise explanation.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. Provide the explanation directly without repeating or quoting the original text;
${g.rule3}
${g.rule4}
5. Answer in a declarative sentence;
6. Respond in ${e}, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}}function W(t){switch(t){case"concise":return 1024;case"standard":return 1536;case"detailed":return 2048;default:return 1024}}function U(t){switch(t){case"concise":return 1536;case"standard":return 2048;case"detailed":return 3072;default:return 1536}}function Q(t,e){const r={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Additional notes:**
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Extended information:**
   xxx;`}}[e];return`You are a browser image text recognition assistant. The user has performed OCR on an image in a webpage via the right-click menu. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, excessive spaces between CJK characters, etc.);
4. Preserve the original line breaks, indentation, and list structures;
${r.rule3}
${r.rule4}
5. Answer in a declarative sentence;
6. Respond in ${t}, translate ALL text elements including section titles, paragraph headings, labels, captions and any other structural text, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}function V(t,e){const r={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Additional notes:**
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Extended information:**
   xxx;`}}[e];return`You are a screenshot text recognition assistant. The user has taken a screenshot and performed OCR to recognize text. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text from a screenshot, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, excessive spaces between CJK characters, etc.);
4. Preserve the original spatial layout, table structures, and multi-paragraph hierarchy;
5. Screenshots may contain UI elements, mixed languages, code snippets, or dialogs — if the content looks like a UI/menu/dialog, describe its function;
${r.rule3}
${r.rule4}
6. Answer in a declarative sentence;
7. Respond in ${t}, translate ALL text elements including section titles, paragraph headings, labels, captions and any other structural text, beautify the output in markdown format;
8. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}console.log("[AI Search] Background service worker loaded");chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.get(["selectedProvider"],t=>{t.selectedProvider||chrome.storage.local.set({selectedProvider:R})})});function E(t){const e=t.replace(/\/+$/,"");return/\/chat\/completions$/i.test(e)?e:e.includes("/v1")?`${e}/chat/completions`:`${e}/v1/chat/completions`}let C=null,$=null;function z(t){return t?t.replace(/[^\x20-\x7E]/g,"").trim():""}async function K(){if(C)return C;const e=(await chrome.storage.local.get(["selectedProvider"])).selectedProvider||R,n=A[e],r=n.storageKey,g=[`${r}ApiKey`,`${r}BaseUrl`,`${r}Model`,"targetLanguage","uiLanguage","contextMaxTokens","explanationDetailLevel"],l=await chrome.storage.local.get(g),d=l.contextMaxTokens,u=F(Number(d)),c=l.explanationDetailLevel,a=c==="concise"||c==="standard"||c==="detailed"?c:"concise",p=(l.uiLanguage||(Y()?"zh":"en"))==="zh"?"中文":"English";return C={provider:e,apiKey:z(l[`${r}ApiKey`]),baseUrl:l[`${r}BaseUrl`]||n.defaultBaseUrl,model:l[`${r}Model`]||n.defaultModel,targetLang:l.targetLanguage||p,contextMaxTokens:u,explanationDetailLevel:a},C}chrome.storage.onChanged.addListener(t=>{const e=["selectedProvider","openaiApiKey","openaiBaseUrl","openaiModel","anthropicApiKey","anthropicBaseUrl","anthropicModel","minimaxApiKey","minimaxBaseUrl","minimaxModel","deepseekApiKey","deepseekBaseUrl","deepseekModel","glmApiKey","glmBaseUrl","glmModel","targetLanguage","contextMaxTokens","explanationDetailLevel"];for(const n of e)if(t[n]){C=null;break}t.translationConcurrency&&($=null)});function D(t){return t==="openai"||t==="deepseek"||t==="glm"?"openai":"anthropic"}async function X(t){const e=await K(),n=e.provider,r=e.apiKey,g=e.baseUrl,l=e.model,d=e.targetLang||t.targetLang||"中文",u=e.contextMaxTokens||J.default,c=e.explanationDetailLevel||"concise",a=t.uiLang?t.uiLang==="zh":t.targetLang!=="en";if(!r)throw new Error(a?"请先在设置页面配置 API Key":"Please configure API Key in settings");const i=t.context.length>u?t.context.substring(0,u)+"...":t.context,p=d.startsWith("中文")||d.toLowerCase().startsWith("zh");let o,s;t.imageText&&t.imageSource==="screenshot-ocr"?(o=V(d,c),s=U(c)):t.imageText?(o=Q(d,c),s=U(c)):(o=j(p,d,c),s=W(c));const f=t.imageText?`
<image_content>${t.imageText}</image_content>`:"",y=`
<url>${t.pageUrl||"unknown"}</url>
<title>${t.pageTitle||"unknown"}</title>
<context>${i}</context>${f}
<selection>${t.selection}</selection>`,h=A[n],b=n==="openai"?E(g):`${g}${h.endpointPath}`,x=h.authHeader==="Bearer"?`Bearer ${r}`:r,m=D(n),w=m==="openai"?{model:l,max_tokens:s,temperature:.1,messages:[{role:"system",content:o},{role:"user",content:y}],stream:!0}:{model:l,max_tokens:s,temperature:.1,system:o,messages:[{role:"user",content:y}],stream:!0},k={"Content-Type":"application/json",[h.authHeader==="Bearer"?"Authorization":"x-api-key"]:x,...h.extraHeaders};return{provider:n,streamFormat:m,endpoint:b,headers:k,requestBody:w,isChineseUI:a}}async function G(t){const e=await K(),n=e.provider,r=e.apiKey,g=e.baseUrl,l=e.model,d=t.uiLang?t.uiLang==="zh":!0;if(!r)throw new Error(d?"请先在设置页面配置 API Key":"Please configure API Key in settings");const u=`You are a Japanese reading assistant. Add ruby annotations to Japanese text.

【Rules】
1. Output ONLY the annotated text in HTML using <ruby> and <rt>;
2. Keep the original text content intact (including kanji, kana, punctuation, spacing, and line breaks);
3. Annotate ONLY kanji with hiragana in <rt>;
4. Do NOT add ruby to non-kanji text (Latin letters, numbers, kana, symbols);
5. Do NOT include any other HTML tags, markdown, or explanations.`,c=`Annotate this Japanese text with ruby (hiragana in <rt>):

${t.text}`,a=A[n],i=n==="openai"?E(g):`${g}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${r}`:r,o=D(n),s=o==="openai"?{model:l,max_tokens:1024,temperature:.1,messages:[{role:"system",content:u},{role:"user",content:c}],stream:!0}:{model:l,max_tokens:1024,temperature:.1,system:u,messages:[{role:"user",content:c}],stream:!0},f={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders};return{provider:n,streamFormat:o,endpoint:i,headers:f,requestBody:s,isChineseUI:d}}async function B(t){let e=`HTTP ${t.status}`;try{const n=await t.json();e=n.error?.message||n.message||JSON.stringify(n)}catch{e=await t.text()||e}return e}function L(t){const e=t,n=e?.choices?.[0]?.delta?.content,r=e?.choices?.[0]?.finish_reason;return{delta:typeof n=="string"&&n.length>0?n:void 0,done:typeof r=="string"&&r.length>0?!0:void 0}}function v(t){const e=t;if(e?.type==="content_block_delta"){const n=e?.delta?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}if(e?.type==="content_block_start"){const n=e?.content_block?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}return e?.type==="message_delta"&&e?.delta?.stop_reason?{done:!0}:e?.type==="message_stop"?{done:!0}:typeof e?.text=="string"&&e.text.length>0?{delta:e.text}:e?.content?.[0]?.text&&typeof e.content[0].text=="string"?{delta:e.content[0].text}:{}}async function Z(t,e){const{streamFormat:n,endpoint:r,headers:g,requestBody:l,isChineseUI:d}=await X(t),u=new AbortController;let c,a=!1;const i=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Safe postMessage failed:",f)}},p=()=>{a=!0,c&&clearTimeout(c),u.abort()};e.onDisconnect.addListener(p),c=setTimeout(()=>{u.abort(),i({type:"error",error:d?"请求超时（30秒）":"Request timeout (30s)"})},_);let o=!1;try{console.log("[AI Search] requestBody (stream):",JSON.stringify(l,null,2));const s=await fetch(r,{method:"POST",headers:g,body:JSON.stringify(l),signal:u.signal});if(!s.ok)throw new Error(await B(s));const f=s.body?.getReader();if(!f)throw new Error(d?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let h="";for(;;){const{value:x,done:m}=await f.read();if(m)break;h+=y.decode(x,{stream:!0});const w=h.split(/\r?\n/);h=w.pop()||"";for(const k of w){const S=k.trim();if(!S||!S.startsWith("data:"))continue;const O=S.slice(5).trim();if(O==="[DONE]"){o=!0,i({type:"done"});return}try{const T=JSON.parse(O),P=n==="openai"?L(T):v(T);if(P.delta&&i({type:"delta",data:P.delta}),P.done){o=!0,i({type:"done"});return}}catch(T){console.warn("[AI Search] Stream chunk parse error:",T)}}}const b=h.trim();if(b.startsWith("data:")){const x=b.slice(5).trim();if(x==="[DONE]"){o=!0,i({type:"done"});return}try{const m=JSON.parse(x),w=n==="openai"?L(m):v(m);if(w.delta&&i({type:"delta",data:w.delta}),w.done){o=!0,i({type:"done"});return}}catch(m){console.warn("[AI Search] Stream tail parse error:",m)}}}catch(s){s.name!=="AbortError"&&i({type:"error",error:s.message||String(s)})}finally{clearTimeout(c),e.onDisconnect.removeListener(p),o||i({type:"done"})}}async function ee(t,e){const{streamFormat:n,endpoint:r,headers:g,requestBody:l,isChineseUI:d}=await G(t),u=new AbortController;let c,a=!1;const i=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Kana safe postMessage failed:",f)}},p=()=>{a=!0,c&&clearTimeout(c),u.abort()};e.onDisconnect.addListener(p),c=setTimeout(()=>{u.abort(),i({type:"error",error:d?"请求超时（30秒）":"Request timeout (30s)"})},_);let o=!1;try{console.log("[AI Search] kana requestBody (stream):",JSON.stringify(l,null,2));const s=await fetch(r,{method:"POST",headers:g,body:JSON.stringify(l),signal:u.signal});if(!s.ok)throw new Error(await B(s));const f=s.body?.getReader();if(!f)throw new Error(d?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let h="";for(;;){const{value:x,done:m}=await f.read();if(m)break;h+=y.decode(x,{stream:!0});const w=h.split(/\r?\n/);h=w.pop()||"";for(const k of w){const S=k.trim();if(!S||!S.startsWith("data:"))continue;const O=S.slice(5).trim();if(O==="[DONE]"){o=!0,i({type:"done"});return}try{const T=JSON.parse(O),P=n==="openai"?L(T):v(T);if(P.delta&&i({type:"delta",data:P.delta}),P.done){o=!0,i({type:"done"});return}}catch(T){console.warn("[AI Search] Kana stream chunk parse error:",T)}}}const b=h.trim();if(b.startsWith("data:")){const x=b.slice(5).trim();if(x==="[DONE]"){o=!0,i({type:"done"});return}try{const m=JSON.parse(x),w=n==="openai"?L(m):v(m);if(w.delta&&i({type:"delta",data:w.delta}),w.done){o=!0,i({type:"done"});return}}catch(m){console.warn("[AI Search] Kana stream tail parse error:",m)}}}catch(s){s.name!=="AbortError"&&i({type:"error",error:s.message||String(s)})}finally{clearTimeout(c),e.onDisconnect.removeListener(p),o||i({type:"done"})}}chrome.runtime.onConnect.addListener(t=>{t.name!=="ai-stream"&&t.name!=="ai-translate-stream"&&t.name!=="ai-kana-stream"&&t.name!=="ai-test-connection"||t.onMessage.addListener(e=>{e?.action==="testConnection"?ce(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryAIStream"?Z(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryKana"?ee(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="inlineTranslate"?re(e.payload,t):e?.action==="inlineTranslateBatch"&&ie(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})})})});const M=[];let N=0;function te(t){const e=M.indexOf(t);e>=0&&M.splice(e,1)}async function ne(){if($!==null)return $;const e=(await chrome.storage.local.get(["translationConcurrency"])).translationConcurrency,n=q(Number(e));return $=n,n}async function H(){const t=await ne();for(;N<t&&M.length>0;){const e=M.shift();if(!e.canceled){e.started=!0;try{e.port.onDisconnect.removeListener(e.onDisconnect)}catch{}N+=1,se(e.payload,e.port).catch(n=>{e.port.postMessage({type:"error",error:n?.message||String(n)})}).finally(()=>{N-=1,H().catch(n=>{console.warn("[Inline Translate] Queue process error:",n)})})}}}function re(t,e){const n={payload:t,port:e,started:!1,canceled:!1,onDisconnect:()=>{n.started||(n.canceled=!0,te(n))}};e.onDisconnect.addListener(n.onDisconnect),M.push(n),H().catch(r=>{console.warn("[Inline Translate] Queue process error:",r)})}async function ae(t){const e=await K(),n=e.provider,r=e.apiKey,g=e.baseUrl,l=e.model,d=e.targetLang||t.targetLang||"English",u=t.uiLang?t.uiLang==="zh":d!=="en";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=`You are a professional translator. Your task is to translate text to ${d}.

【Rules】
1. Output ONLY the translation, nothing else (no original text, no explanations);
2. Keep the translation accurate and natural;
3. Preserve the original meaning and tone;
4. Use Markdown format for better readability;
5. Do NOT use code blocks, inline code, or HTML tags;
6. Preserve any placeholder tokens like [[[T0]]] exactly and keep them in the same order;`,a=`Translate this text to ${d}:

${t.selection}`,i=A[n],p=n==="openai"?E(g):`${g}${i.endpointPath}`,o=i.authHeader==="Bearer"?`Bearer ${r}`:r,s=D(n),f=s==="openai"?{model:l,max_tokens:1024,temperature:.1,messages:[{role:"system",content:c},{role:"user",content:a}],stream:!0}:{model:l,max_tokens:1024,temperature:.1,system:c,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[i.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...i.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function oe(t){const e=await K(),n=e.provider,r=e.apiKey,g=e.baseUrl,l=e.model,d=e.targetLang||t.targetLang||"English",u=t.uiLang?t.uiLang==="zh":d!=="en";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=`You are a professional translator. Your task is to translate a JSON array of texts to ${d}.

【Rules】
1. You will receive a JSON array of strings.
2. You must return a valid JSON array of strings containing the translations.
3. The order of translations MUST match the original array.
4. Output ONLY the JSON array, nothing else (no code blocks, no explanations).
5. Ensure the JSON is valid (properly escaped).`,a=JSON.stringify(t.selections),i=A[n],p=n==="openai"?E(g):`${g}${i.endpointPath}`,o=i.authHeader==="Bearer"?`Bearer ${r}`:r,s=D(n),f=s==="openai"?{model:l,max_tokens:4096,temperature:.1,messages:[{role:"system",content:c},{role:"user",content:a}],stream:!0}:{model:l,max_tokens:4096,temperature:.1,system:c,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[i.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...i.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function se(t,e){const{streamFormat:n,endpoint:r,headers:g,requestBody:l}=await ae(t),d=new AbortController;let u,c=!1;const a=o=>{if(!c)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate] Safe postMessage failed:",s)}},i=()=>{c=!0,u&&clearTimeout(u),d.abort()};e.onDisconnect.addListener(i),u=setTimeout(()=>{d.abort(),a({type:"error",error:"Request timeout (30s)"})},_);let p=!1;try{console.log("[Inline Translate] requestBody:",JSON.stringify(l,null,2));const o=await fetch(r,{method:"POST",headers:g,body:JSON.stringify(l),signal:d.signal});if(!o.ok)throw new Error(await B(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:x}=await s.read();if(x)break;y+=f.decode(b,{stream:!0});const m=y.split(/\r?\n/);y=m.pop()||"";for(const w of m){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const S=k.slice(5).trim();if(S==="[DONE]"){p=!0,a({type:"done"});return}try{const O=JSON.parse(S),T=n==="openai"?L(O):v(O);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch(O){console.warn("[Inline Translate] Stream chunk parse error:",O)}}}const h=y.trim();if(h.startsWith("data:")){const b=h.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const x=JSON.parse(b),m=n==="openai"?L(x):v(x);if(m.delta&&a({type:"delta",data:m.delta}),m.done){p=!0,a({type:"done"});return}}catch(x){console.warn("[Inline Translate] Stream tail parse error:",x)}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(u),e.onDisconnect.removeListener(i),p||a({type:"done"})}}async function ie(t,e){const{streamFormat:n,endpoint:r,headers:g,requestBody:l}=await oe(t),d=new AbortController;let u,c=!1;const a=o=>{if(!c)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate Batch] Safe postMessage failed:",s)}},i=()=>{c=!0,u&&clearTimeout(u),d.abort()};e.onDisconnect.addListener(i),u=setTimeout(()=>{d.abort(),a({type:"error",error:"Request timeout (45s)"})},45e3);let p=!1;try{const o=await fetch(r,{method:"POST",headers:g,body:JSON.stringify(l),signal:d.signal});if(!o.ok)throw new Error(await B(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:x}=await s.read();if(x)break;y+=f.decode(b,{stream:!0});const m=y.split(/\r?\n/);y=m.pop()||"";for(const w of m){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const S=k.slice(5).trim();if(S==="[DONE]"){p=!0,a({type:"done"});return}try{const O=JSON.parse(S),T=n==="openai"?L(O):v(O);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch{}}}const h=y.trim();if(h.startsWith("data:")){const b=h.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const x=JSON.parse(b),m=n==="openai"?L(x):v(x);if(m.delta&&a({type:"delta",data:m.delta}),m.done){p=!0,a({type:"done"});return}}catch{}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(u),e.onDisconnect.removeListener(i),p||a({type:"done"})}}async function ce(t,e){const{provider:n,apiKey:r,baseUrl:g,model:l,uiLang:d}=t,u=d==="zh";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=z(r),a=A[n],i=n==="openai"?E(g):`${g}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${c}`:c,o={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders},s=D(n),f="Ping",y=s==="openai"?{model:l,max_tokens:5,messages:[{role:"user",content:f}],stream:!1}:{model:l,max_tokens:5,system:"Respond only with OK",messages:[{role:"user",content:f}],stream:!1};try{const h=await fetch(i,{method:"POST",headers:o,body:JSON.stringify(y)});if(!h.ok)throw new Error(await B(h));e.postMessage({type:"success"})}catch(h){e.postMessage({type:"error",error:h.message||String(h)})}}chrome.runtime.onInstalled.addListener(async()=>{(await chrome.storage.local.get(["ocr_enabled"])).ocr_enabled!==!1&&await I.createMenus()});chrome.storage.onChanged.addListener(async t=>{t.ocr_enabled&&(t.ocr_enabled.newValue?await I.createMenus():I.destroy())});chrome.runtime.onMessage.addListener((t,e,n)=>{if(t.action==="create-context-menu")return I.createMenus().then(()=>n({success:!0})).catch(r=>n({error:r.message})),!0;if(t.action==="clear-context-menu")I.destroy(),n({success:!0});else if(t.action==="capture-screenshot"){if(!e.tab?.windowId){n({error:"No active tab"});return}return chrome.tabs.captureVisibleTab(e.tab.windowId,{format:"png"},r=>{chrome.runtime.lastError?(console.error("[Background] Screenshot capture failed:",chrome.runtime.lastError.message),n({error:chrome.runtime.lastError.message})):n({dataUrl:r})}),!0}});
