import{D as R,P as A}from"./providers-CEYn_6Hv.js";import{R as _,C as J,c as q,a as F}from"./api-DQFr13Pf.js";import{a as Y}from"./language-DQz3GEpC.js";import{contextMenuService as I}from"./contextMenuService-wm2oCVVN.js";function j(t,e,n){if(t){const m={concise:{rule3:"3. 生成解释时保持回答内容精炼简短，只输出核心含义，不要冗长啰嗦;",rule4:`4. 必须严格按以下格式输出回答内容 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx`},standard:{rule3:"3. 生成解释时提供适度详细的内容，可根据选中内容的性质补充必要的背景信息;",rule4:`4. 必须按以下基本格式输出，可根据需要添加"补充说明"部分 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx
   **补充说明（可选）**:
   xxx`},detailed:{rule3:"3. 生成解释时尽可能详尽，提供丰富的背景知识、相关概念或延伸信息;",rule4:`4. 按以下基本格式输出，并添加详细的补充说明 (小标题必须加粗，冒号后换行输出内容):
   **基础含义**:
   xxx
   **上下文中的含义**:
   xxx
   **延伸信息**:
   xxx`}}[n];return`你是一个浏览器划词解释助手。请根据用户选中的内容,结合上下文进行理解,对选中内容进行解释和翻译。

【必须遵守的规则】
1. 首先输出原文语言标签: <source_lang>xx</source_lang>,xx为语言代码(en/ja/zh/ko/fr/de/es等);
2. 直接给出解释内容，不要重复或引用原文;
${m.rule3}
${m.rule4}
5. 请以陈述句回答;
6. 用中文回答,按markdown格式美化输出;
7. 禁止使用代码块、内联代码或HTML标签(例如: \`\`\`、\`code\`、<tag>,但source_lang标签除外)`}else{const m={concise:{rule3:"3. Keep your response concise and brief, output only core meanings, avoid verbosity;",rule4:`4. You MUST output in the following format only, nothing else (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;`},standard:{rule3:"3. Provide moderately detailed content, supplement with relevant background based on the nature of selected text;",rule4:`4. Output in the following base format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;
   **Additional notes (optional)**: 
   xxx;`},detailed:{rule3:"3. Be as detailed as possible, provide rich background knowledge, related concepts, or extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Base meaning**: 
   xxx;
   **Contextual meaning**: 
   xxx;
   **Extended information**: 
   xxx;`}}[n];return`You are a browser selection explanation assistant. Please explain the selected text based on the context and the selected text, give a precise and concise explanation.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. Provide the explanation directly without repeating or quoting the original text;
${m.rule3}
${m.rule4}
5. Answer in a declarative sentence;
6. Respond in ${e}, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}}function W(t){switch(t){case"concise":return 1024;case"standard":return 1536;case"detailed":return 2048;default:return 1024}}function U(t){switch(t){case"concise":return 1536;case"standard":return 2048;case"detailed":return 3072;default:return 1536}}function Q(t,e){const r={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Additional notes:**
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Extended information:**
   xxx;`}}[e];return`You are a browser image text recognition assistant. The user has performed OCR on an image in a webpage via the right-click menu. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, excessive spaces between CJK characters, etc.);
4. Preserve the original line breaks, indentation, and list structures;
${r.rule3}
${r.rule4}
5. Answer in a declarative sentence;
6. Respond in ${t}, translate ALL text elements including section titles, paragraph headings, labels, captions and any other structural text, beautify the output in markdown format;
7. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}function V(t,e){const r={concise:{rule3:"3. Keep your response concise, output only core recognized text and brief translation;",rule4:`4. You MUST output in the following format only (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;`},standard:{rule3:"3. Provide moderately detailed content including recognized text, translation, and relevant background;",rule4:`4. Output in the following format, you may add an "Additional notes" section if helpful (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Additional notes:**
   xxx;`},detailed:{rule3:"3. Be as detailed as possible with complete recognized text, translation, background knowledge and extended information;",rule4:`4. Output in the following format with detailed supplementary information (section headers must be bold, content on a new line after the colon):
   **Translation:**
   xxx;
   **Explanation:**
   xxx;
   **Extended information:**
   xxx;`}}[e];return`You are a screenshot text recognition assistant. The user has taken a screenshot and performed OCR to recognize text. Please translate and explain the recognized text.

【Must follow rules】
1. First output source language tag: <source_lang>xx</source_lang>, where xx is the language code (en/ja/zh/ko/fr/de/es, etc.);
2. The content in the <image_content> tag is the raw OCR-recognized text from a screenshot, which may contain recognition errors;
3. Automatically correct common OCR errors (e.g., 0/O confusion, 1/l/I confusion, rn/m confusion, hyphenated line breaks, excessive spaces between CJK characters, etc.);
4. Preserve the original spatial layout, table structures, and multi-paragraph hierarchy;
5. Screenshots may contain UI elements, mixed languages, code snippets, or dialogs — if the content looks like a UI/menu/dialog, describe its function;
${r.rule3}
${r.rule4}
6. Answer in a declarative sentence;
7. Respond in ${t}, translate ALL text elements including section titles, paragraph headings, labels, captions and any other structural text, beautify the output in markdown format;
8. Do not use code blocks, inline code, or HTML tags (e.g., \`\`\` or \`code\` or <tag>, except source_lang tag)`}console.log("[AI Search] Background service worker loaded");chrome.runtime.onInstalled.addListener(()=>{chrome.storage.local.get(["selectedProvider"],t=>{t.selectedProvider||chrome.storage.local.set({selectedProvider:R})})});function E(t){const e=t.replace(/\/+$/,"");return/\/chat\/completions$/i.test(e)?e:e.includes("/v1")?`${e}/chat/completions`:`${e}/v1/chat/completions`}let C=null,$=null;function H(t){return t?t.replace(/[^\x20-\x7E]/g,"").trim():""}async function K(){if(C)return C;const e=(await chrome.storage.local.get(["selectedProvider"])).selectedProvider||R,n=A[e],r=n.storageKey,m=[`${r}ApiKey`,`${r}BaseUrl`,`${r}Model`,"targetLanguage","contextMaxTokens","explanationDetailLevel"],d=await chrome.storage.local.get(m),l=d.contextMaxTokens,u=F(Number(l)),c=d.explanationDetailLevel,a=c==="concise"||c==="standard"||c==="detailed"?c:"concise";return C={provider:e,apiKey:H(d[`${r}ApiKey`]),baseUrl:d[`${r}BaseUrl`]||n.defaultBaseUrl,model:d[`${r}Model`]||n.defaultModel,targetLang:d.targetLanguage||(Y()?"中文":"English"),contextMaxTokens:u,explanationDetailLevel:a},C}chrome.storage.onChanged.addListener(t=>{const e=["selectedProvider","openaiApiKey","openaiBaseUrl","openaiModel","anthropicApiKey","anthropicBaseUrl","anthropicModel","minimaxApiKey","minimaxBaseUrl","minimaxModel","deepseekApiKey","deepseekBaseUrl","deepseekModel","glmApiKey","glmBaseUrl","glmModel","targetLanguage","contextMaxTokens","explanationDetailLevel"];for(const n of e)if(t[n]){C=null;break}t.translationConcurrency&&($=null)});function D(t){return t==="openai"||t==="deepseek"||t==="glm"?"openai":"anthropic"}async function X(t){const e=await K(),n=e.provider,r=e.apiKey,m=e.baseUrl,d=e.model,l=e.targetLang||t.targetLang||"中文",u=e.contextMaxTokens||J.default,c=e.explanationDetailLevel||"concise",a=t.uiLang?t.uiLang==="zh":t.targetLang!=="en";if(!r)throw new Error(a?"请先在设置页面配置 API Key":"Please configure API Key in settings");const i=t.context.length>u?t.context.substring(0,u)+"...":t.context,p=l.startsWith("中文")||l.toLowerCase().startsWith("zh");let o,s;t.imageText&&t.imageSource==="screenshot-ocr"?(o=V(l,c),s=U(c)):t.imageText?(o=Q(l,c),s=U(c)):(o=j(p,l,c),s=W(c));const f=t.imageText?`
<image_content>${t.imageText}</image_content>`:"",y=`
<url>${t.pageUrl||"unknown"}</url>
<title>${t.pageTitle||"unknown"}</title>
<context>${i}</context>${f}
<selection>${t.selection}</selection>`,h=A[n],b=n==="openai"?E(m):`${m}${h.endpointPath}`,x=h.authHeader==="Bearer"?`Bearer ${r}`:r,g=D(n),w=g==="openai"?{model:d,max_tokens:s,temperature:.1,messages:[{role:"system",content:o},{role:"user",content:y}],stream:!0}:{model:d,max_tokens:s,temperature:.1,system:o,messages:[{role:"user",content:y}],stream:!0},k={"Content-Type":"application/json",[h.authHeader==="Bearer"?"Authorization":"x-api-key"]:x,...h.extraHeaders};return{provider:n,streamFormat:g,endpoint:b,headers:k,requestBody:w,isChineseUI:a}}async function G(t){const e=await K(),n=e.provider,r=e.apiKey,m=e.baseUrl,d=e.model,l=t.uiLang?t.uiLang==="zh":!0;if(!r)throw new Error(l?"请先在设置页面配置 API Key":"Please configure API Key in settings");const u=`You are a Japanese reading assistant. Add ruby annotations to Japanese text.

【Rules】
1. Output ONLY the annotated text in HTML using <ruby> and <rt>;
2. Keep the original text content intact (including kanji, kana, punctuation, spacing, and line breaks);
3. Annotate ONLY kanji with hiragana in <rt>;
4. Do NOT add ruby to non-kanji text (Latin letters, numbers, kana, symbols);
5. Do NOT include any other HTML tags, markdown, or explanations.`,c=`Annotate this Japanese text with ruby (hiragana in <rt>):

${t.text}`,a=A[n],i=n==="openai"?E(m):`${m}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${r}`:r,o=D(n),s=o==="openai"?{model:d,max_tokens:1024,temperature:.1,messages:[{role:"system",content:u},{role:"user",content:c}],stream:!0}:{model:d,max_tokens:1024,temperature:.1,system:u,messages:[{role:"user",content:c}],stream:!0},f={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders};return{provider:n,streamFormat:o,endpoint:i,headers:f,requestBody:s,isChineseUI:l}}async function B(t){let e=`HTTP ${t.status}`;try{const n=await t.json();e=n.error?.message||n.message||JSON.stringify(n)}catch{e=await t.text()||e}return e}function v(t){const e=t,n=e?.choices?.[0]?.delta?.content,r=e?.choices?.[0]?.finish_reason;return{delta:typeof n=="string"&&n.length>0?n:void 0,done:typeof r=="string"&&r.length>0?!0:void 0}}function P(t){const e=t;if(e?.type==="content_block_delta"){const n=e?.delta?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}if(e?.type==="content_block_start"){const n=e?.content_block?.text;return{delta:typeof n=="string"&&n.length>0?n:void 0}}return e?.type==="message_delta"&&e?.delta?.stop_reason?{done:!0}:e?.type==="message_stop"?{done:!0}:typeof e?.text=="string"&&e.text.length>0?{delta:e.text}:e?.content?.[0]?.text&&typeof e.content[0].text=="string"?{delta:e.content[0].text}:{}}async function Z(t,e){const{streamFormat:n,endpoint:r,headers:m,requestBody:d,isChineseUI:l}=await X(t),u=new AbortController;let c,a=!1;const i=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Safe postMessage failed:",f)}},p=()=>{a=!0,c&&clearTimeout(c),u.abort()};e.onDisconnect.addListener(p),c=setTimeout(()=>{u.abort(),i({type:"error",error:l?"请求超时（30秒）":"Request timeout (30s)"})},_);let o=!1;try{console.log("[AI Search] requestBody (stream):",JSON.stringify(d,null,2));const s=await fetch(r,{method:"POST",headers:m,body:JSON.stringify(d),signal:u.signal});if(!s.ok)throw new Error(await B(s));const f=s.body?.getReader();if(!f)throw new Error(l?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let h="";for(;;){const{value:x,done:g}=await f.read();if(g)break;h+=y.decode(x,{stream:!0});const w=h.split(/\r?\n/);h=w.pop()||"";for(const k of w){const S=k.trim();if(!S||!S.startsWith("data:"))continue;const O=S.slice(5).trim();if(O==="[DONE]"){o=!0,i({type:"done"});return}try{const T=JSON.parse(O),L=n==="openai"?v(T):P(T);if(L.delta&&i({type:"delta",data:L.delta}),L.done){o=!0,i({type:"done"});return}}catch(T){console.warn("[AI Search] Stream chunk parse error:",T)}}}const b=h.trim();if(b.startsWith("data:")){const x=b.slice(5).trim();if(x==="[DONE]"){o=!0,i({type:"done"});return}try{const g=JSON.parse(x),w=n==="openai"?v(g):P(g);if(w.delta&&i({type:"delta",data:w.delta}),w.done){o=!0,i({type:"done"});return}}catch(g){console.warn("[AI Search] Stream tail parse error:",g)}}}catch(s){s.name!=="AbortError"&&i({type:"error",error:s.message||String(s)})}finally{clearTimeout(c),e.onDisconnect.removeListener(p),o||i({type:"done"})}}async function ee(t,e){const{streamFormat:n,endpoint:r,headers:m,requestBody:d,isChineseUI:l}=await G(t),u=new AbortController;let c,a=!1;const i=s=>{if(!a)try{e.postMessage(s)}catch(f){console.warn("[AI Search] Kana safe postMessage failed:",f)}},p=()=>{a=!0,c&&clearTimeout(c),u.abort()};e.onDisconnect.addListener(p),c=setTimeout(()=>{u.abort(),i({type:"error",error:l?"请求超时（30秒）":"Request timeout (30s)"})},_);let o=!1;try{console.log("[AI Search] kana requestBody (stream):",JSON.stringify(d,null,2));const s=await fetch(r,{method:"POST",headers:m,body:JSON.stringify(d),signal:u.signal});if(!s.ok)throw new Error(await B(s));const f=s.body?.getReader();if(!f)throw new Error(l?"无法读取流式响应":"Unable to read streaming response");const y=new TextDecoder;let h="";for(;;){const{value:x,done:g}=await f.read();if(g)break;h+=y.decode(x,{stream:!0});const w=h.split(/\r?\n/);h=w.pop()||"";for(const k of w){const S=k.trim();if(!S||!S.startsWith("data:"))continue;const O=S.slice(5).trim();if(O==="[DONE]"){o=!0,i({type:"done"});return}try{const T=JSON.parse(O),L=n==="openai"?v(T):P(T);if(L.delta&&i({type:"delta",data:L.delta}),L.done){o=!0,i({type:"done"});return}}catch(T){console.warn("[AI Search] Kana stream chunk parse error:",T)}}}const b=h.trim();if(b.startsWith("data:")){const x=b.slice(5).trim();if(x==="[DONE]"){o=!0,i({type:"done"});return}try{const g=JSON.parse(x),w=n==="openai"?v(g):P(g);if(w.delta&&i({type:"delta",data:w.delta}),w.done){o=!0,i({type:"done"});return}}catch(g){console.warn("[AI Search] Kana stream tail parse error:",g)}}}catch(s){s.name!=="AbortError"&&i({type:"error",error:s.message||String(s)})}finally{clearTimeout(c),e.onDisconnect.removeListener(p),o||i({type:"done"})}}chrome.runtime.onConnect.addListener(t=>{t.name!=="ai-stream"&&t.name!=="ai-translate-stream"&&t.name!=="ai-kana-stream"&&t.name!=="ai-test-connection"||t.onMessage.addListener(e=>{e?.action==="testConnection"?ce(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryAIStream"?Z(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="queryKana"?ee(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})}):e?.action==="inlineTranslate"?re(e.payload,t):e?.action==="inlineTranslateBatch"&&ie(e.payload,t).catch(n=>{t.postMessage({type:"error",error:n.message||String(n)})})})});const M=[];let N=0;function te(t){const e=M.indexOf(t);e>=0&&M.splice(e,1)}async function ne(){if($!==null)return $;const e=(await chrome.storage.local.get(["translationConcurrency"])).translationConcurrency,n=q(Number(e));return $=n,n}async function z(){const t=await ne();for(;N<t&&M.length>0;){const e=M.shift();if(!e.canceled){e.started=!0;try{e.port.onDisconnect.removeListener(e.onDisconnect)}catch{}N+=1,se(e.payload,e.port).catch(n=>{e.port.postMessage({type:"error",error:n?.message||String(n)})}).finally(()=>{N-=1,z().catch(n=>{console.warn("[Inline Translate] Queue process error:",n)})})}}}function re(t,e){const n={payload:t,port:e,started:!1,canceled:!1,onDisconnect:()=>{n.started||(n.canceled=!0,te(n))}};e.onDisconnect.addListener(n.onDisconnect),M.push(n),z().catch(r=>{console.warn("[Inline Translate] Queue process error:",r)})}async function ae(t){const e=await K(),n=e.provider,r=e.apiKey,m=e.baseUrl,d=e.model,l=e.targetLang||t.targetLang||"English",u=t.uiLang?t.uiLang==="zh":l!=="en";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=`You are a professional translator. Your task is to translate text to ${l}.

【Rules】
1. Output ONLY the translation, nothing else (no original text, no explanations);
2. Keep the translation accurate and natural;
3. Preserve the original meaning and tone;
4. Use Markdown format for better readability;
5. Do NOT use code blocks, inline code, or HTML tags;
6. Preserve any placeholder tokens like [[[T0]]] exactly and keep them in the same order;`,a=`Translate this text to ${l}:

${t.selection}`,i=A[n],p=n==="openai"?E(m):`${m}${i.endpointPath}`,o=i.authHeader==="Bearer"?`Bearer ${r}`:r,s=D(n),f=s==="openai"?{model:d,max_tokens:1024,temperature:.1,messages:[{role:"system",content:c},{role:"user",content:a}],stream:!0}:{model:d,max_tokens:1024,temperature:.1,system:c,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[i.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...i.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function oe(t){const e=await K(),n=e.provider,r=e.apiKey,m=e.baseUrl,d=e.model,l=e.targetLang||t.targetLang||"English",u=t.uiLang?t.uiLang==="zh":l!=="en";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=`You are a professional translator. Your task is to translate a JSON array of texts to ${l}.

【Rules】
1. You will receive a JSON array of strings.
2. You must return a valid JSON array of strings containing the translations.
3. The order of translations MUST match the original array.
4. Output ONLY the JSON array, nothing else (no code blocks, no explanations).
5. Ensure the JSON is valid (properly escaped).`,a=JSON.stringify(t.selections),i=A[n],p=n==="openai"?E(m):`${m}${i.endpointPath}`,o=i.authHeader==="Bearer"?`Bearer ${r}`:r,s=D(n),f=s==="openai"?{model:d,max_tokens:4096,temperature:.1,messages:[{role:"system",content:c},{role:"user",content:a}],stream:!0}:{model:d,max_tokens:4096,temperature:.1,system:c,messages:[{role:"user",content:a}],stream:!0},y={"Content-Type":"application/json",[i.authHeader==="Bearer"?"Authorization":"x-api-key"]:o,...i.extraHeaders};return{provider:n,streamFormat:s,endpoint:p,headers:y,requestBody:f}}async function se(t,e){const{streamFormat:n,endpoint:r,headers:m,requestBody:d}=await ae(t),l=new AbortController;let u,c=!1;const a=o=>{if(!c)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate] Safe postMessage failed:",s)}},i=()=>{c=!0,u&&clearTimeout(u),l.abort()};e.onDisconnect.addListener(i),u=setTimeout(()=>{l.abort(),a({type:"error",error:"Request timeout (30s)"})},_);let p=!1;try{console.log("[Inline Translate] requestBody:",JSON.stringify(d,null,2));const o=await fetch(r,{method:"POST",headers:m,body:JSON.stringify(d),signal:l.signal});if(!o.ok)throw new Error(await B(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:x}=await s.read();if(x)break;y+=f.decode(b,{stream:!0});const g=y.split(/\r?\n/);y=g.pop()||"";for(const w of g){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const S=k.slice(5).trim();if(S==="[DONE]"){p=!0,a({type:"done"});return}try{const O=JSON.parse(S),T=n==="openai"?v(O):P(O);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch(O){console.warn("[Inline Translate] Stream chunk parse error:",O)}}}const h=y.trim();if(h.startsWith("data:")){const b=h.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const x=JSON.parse(b),g=n==="openai"?v(x):P(x);if(g.delta&&a({type:"delta",data:g.delta}),g.done){p=!0,a({type:"done"});return}}catch(x){console.warn("[Inline Translate] Stream tail parse error:",x)}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(u),e.onDisconnect.removeListener(i),p||a({type:"done"})}}async function ie(t,e){const{streamFormat:n,endpoint:r,headers:m,requestBody:d}=await oe(t),l=new AbortController;let u,c=!1;const a=o=>{if(!c)try{e.postMessage(o)}catch(s){console.warn("[Inline Translate Batch] Safe postMessage failed:",s)}},i=()=>{c=!0,u&&clearTimeout(u),l.abort()};e.onDisconnect.addListener(i),u=setTimeout(()=>{l.abort(),a({type:"error",error:"Request timeout (45s)"})},45e3);let p=!1;try{const o=await fetch(r,{method:"POST",headers:m,body:JSON.stringify(d),signal:l.signal});if(!o.ok)throw new Error(await B(o));const s=o.body?.getReader();if(!s)throw new Error("Unable to read streaming response");const f=new TextDecoder;let y="";for(;;){const{value:b,done:x}=await s.read();if(x)break;y+=f.decode(b,{stream:!0});const g=y.split(/\r?\n/);y=g.pop()||"";for(const w of g){const k=w.trim();if(!k||!k.startsWith("data:"))continue;const S=k.slice(5).trim();if(S==="[DONE]"){p=!0,a({type:"done"});return}try{const O=JSON.parse(S),T=n==="openai"?v(O):P(O);if(T.delta&&a({type:"delta",data:T.delta}),T.done){p=!0,a({type:"done"});return}}catch{}}}const h=y.trim();if(h.startsWith("data:")){const b=h.slice(5).trim();if(b==="[DONE]"){p=!0,a({type:"done"});return}try{const x=JSON.parse(b),g=n==="openai"?v(x):P(x);if(g.delta&&a({type:"delta",data:g.delta}),g.done){p=!0,a({type:"done"});return}}catch{}}}catch(o){o.name!=="AbortError"&&a({type:"error",error:o.message||String(o)})}finally{clearTimeout(u),e.onDisconnect.removeListener(i),p||a({type:"done"})}}async function ce(t,e){const{provider:n,apiKey:r,baseUrl:m,model:d,uiLang:l}=t,u=l==="zh";if(!r)throw new Error(u?"请先在设置页面配置 API Key":"Please configure API Key in settings");const c=H(r),a=A[n],i=n==="openai"?E(m):`${m}${a.endpointPath}`,p=a.authHeader==="Bearer"?`Bearer ${c}`:c,o={"Content-Type":"application/json",[a.authHeader==="Bearer"?"Authorization":"x-api-key"]:p,...a.extraHeaders},s=D(n),f="Ping",y=s==="openai"?{model:d,max_tokens:5,messages:[{role:"user",content:f}],stream:!1}:{model:d,max_tokens:5,system:"Respond only with OK",messages:[{role:"user",content:f}],stream:!1};try{const h=await fetch(i,{method:"POST",headers:o,body:JSON.stringify(y)});if(!h.ok)throw new Error(await B(h));e.postMessage({type:"success"})}catch(h){e.postMessage({type:"error",error:h.message||String(h)})}}chrome.runtime.onInstalled.addListener(async()=>{(await chrome.storage.local.get(["ocr_enabled"])).ocr_enabled!==!1&&await I.createMenus()});chrome.storage.onChanged.addListener(async t=>{t.ocr_enabled&&(t.ocr_enabled.newValue?await I.createMenus():I.destroy())});chrome.runtime.onMessage.addListener((t,e,n)=>{if(t.action==="create-context-menu")return I.createMenus().then(()=>n({success:!0})).catch(r=>n({error:r.message})),!0;if(t.action==="clear-context-menu")I.destroy(),n({success:!0});else if(t.action==="capture-screenshot"){if(!e.tab?.windowId){n({error:"No active tab"});return}return chrome.tabs.captureVisibleTab(e.tab.windowId,{format:"png"},r=>{chrome.runtime.lastError?(console.error("[Background] Screenshot capture failed:",chrome.runtime.lastError.message),n({error:chrome.runtime.lastError.message})):n({dataUrl:r})}),!0}});
